// 配置文件改完，需要重启服务器
module.exports = {
  lintOnSave: false,

  // 反向代理 node(http-proxy-middleware)=>gulp,webpack=>vue脚手架=>vue.config.js,
  devServer: {
    proxy: {
      '/ajax': {
        target: 'https://m.maoyan.com',
        changeOrigin: true
      }
      // "/h5":{

      // }
    }
  }
}
