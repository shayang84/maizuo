<template>
    <footer>
        <ul>

                <!-- 声明式导航  <a href></a>  router-link -->
                <!-- 编程式导航  location.href=""  this.$router-->

                <!-- vue2+vue router3 tag="li" -->
                <!-- vue3 +vue router4 -->
            <router-link :to=" '/films' " custom v-slot="{navigate,isActive}">
                <li @click="navigate" :class="isActive?'kerwinactive':''">
                     <i class="iconfont icon-all"></i>
                    <span>电影</span>
                </li>
            </router-link>

            <router-link :to=" '/cinemas' " custom v-slot="{navigate,isActive}">
                <li @click="navigate" :class="isActive?'kerwinactive':''">
                    <i class="iconfont icon-all"></i>
                    <span>影院</span>

                </li>
            </router-link>

            <router-link :to=" '/center' " custom v-slot="{navigate,isActive}">
                <li @click="navigate" :class="isActive?'kerwinactive':''">
                    <i class="iconfont icon-all"></i>
                    <span>我的</span>

                </li>
            </router-link>
        </ul>
    </footer>
</template>
<script>
import '../assets/iconfont/iconfont.css' // 引入css模块
export default {

}
</script>
<style scoped lang="scss">
    .kerwinactive{
        color:red;
        // background: yellow;
    }

    footer {
        position: fixed;
        left:0;
        bottom: 0;
        width:100%;
        height: 50px;
        line-height: 25px;
        ul{
            display:flex;
            li{
                flex:1;
                text-align: center;
                display: flex;
                flex-direction: column;
            }
        }
    }
</style>
