import { createRouter, createWebHashHistory } from 'vue-router'
import Films from '../views/Films.vue'
import Nowplaying from '../views/films/Nowplaying.vue'
import Comingsoon from '../views/films/Comingsoon.vue'
import Cinemas from '../views/Cinemas.vue'
// import Center from '../views/Center.vue'
import Detail from '../views/Detail.vue'
// import Login from '../views/Login.vue'
const routes = [
  // {
  //   path: '/',
  //   component: Films
  // },
  {
    path: '/films',
    component: Films,
    children: [
      {
        path: '/films/nowplaying',
        component: Nowplaying
      },
      {
        path: '/films/comingsoon',
        component: Comingsoon
      },
      {
        path: '/films',
        redirect: '/films/nowplaying'
      }
    ]
  },
  // {
  //   path: '/films/nowplaying',
  //   component: Nowplaying
  // },
  {
    path: '/cinemas',
    component: Cinemas
  },
  {
    path: '/login',
    component: () => import('../views/Login.vue')
  },
  {
    // 动态路由
    path: '/detail/:myid', // /detail/1111 /detail/2222
    component: Detail
  },
  {
    path: '/center',
    component: () => import('../views/Center.vue'),
    // 路由元信息
    meta: {
      requiresAuth: true
    }
  },
  // {
  //   path: '*',
  //   redirect: '/films' // 重定向
  // }  vue2 +vue router 3 // 非上面路径都会被重定向到films路径
  {
    path: '/:kerwin(.*)*',
    redirect: '/films'
  }// vue3 +vuerouter 4    /b
]

const router = createRouter({
  // history: createWebHistory(process.env.BASE_URL), // history模式 /films

  history: createWebHashHistory(), // hash #/films
  routes
})

router.beforeEach((to, from, next) => {
  // 而不是去检查每条路由记录
  // to.matched.some(record => record.meta.requiresAuth)
  if (to.meta.requiresAuth) {
    // 此路由需要授权，请检查是否已登录
    // 如果没有，则重定向到登录页面
    console.log('拦截')
    if (localStorage.getItem('token')) {
      next()
    } else {
      next('/login')
    }
  } else {
    next()
  }
})

// router.afterEach

export default router
/*
 1. 单文件组件 -- 模糊查询，
 2. 单文件组件 -- 轮播
 3. 路由开发 -- 路由任务 --反向代理-取数据
*/

/*
  1. 一级路由&多级路由
  2. 嵌套路由
  3. 重定向
  4. 编程式导航vs 声明式导航（动态创建？）
  5. 动态路由（列表 传参数=>详情/detail/:myid 获取参数?）
  6. 路由模式  history. hash
  7. 路由拦截&守卫
  8. 路由懒加载
*/
