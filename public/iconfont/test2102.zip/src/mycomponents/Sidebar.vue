<template>
  <div>
    <ul>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
      <li>sidebar</li>
    </ul>
  </div>
</template>
<style scoped lang="scss">
    $width:300px;
    ul {
        li {
            width: $width;
            background: red;
        }
    }
</style>
