<template>
    <div>
        child 组件--{{mytitle}}

        <slot></slot>
    </div>
</template>
<script>
export default {
  props: ['mytitle']
}
</script>
