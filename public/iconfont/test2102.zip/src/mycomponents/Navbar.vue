<template>
    <div>
        navbar-<slot></slot>
    </div>
</template>
