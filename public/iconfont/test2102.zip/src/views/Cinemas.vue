<template>
    <div>
        cinema
    </div>
</template>
