<template>
    <div>
        <ul>
            <li v-for="data in datalist" :key="data" @click="handleClick(data)">
                {{data}}
            </li>
        </ul>
    </div>
</template>

<script>
export default {
  data () {
    return {
      datalist: ['1111', '2222', '3333', '44444']
    }
  },
  methods: {
    handleClick (id) {
    //   location.href = '#/center'
    //   console.log()
      this.$router.push(`/detail/${id}`)
    }
  }
}
</script>
