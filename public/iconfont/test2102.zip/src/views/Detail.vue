<template>
    <div>
        detail
    </div>
</template>

<script>
export default {
  mounted () {
    // 当前匹配的对象
    console.log(this.$route.params.myid, '跟后端对接 get传id，获取当前页面的详情')
  }
}
</script>
